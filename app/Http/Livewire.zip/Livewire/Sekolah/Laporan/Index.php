<?php

namespace App\Http\Livewire\Sekolah\Laporan;

use App\Models\Admin\DayaTampung;
use Livewire\Component;
use Barryvdh\DomPDF\Facade\Pdf as DomPDFPDF;
use Illuminate\Support\Facades\Auth;
use App\Models\Admin\Pendaftar as LivewirePendaftar;
use App\Models\Admin\PorsiSiswa;
use PhpOffice\PhpSpreadsheet\Calculation\DateTimeExcel\Days;

class Index extends Component
{
    public $data_jalur, $jenis_data;
    public function render()
    {
        return view('livewire.sekolah.laporan.index');
    }


    // cetak data
    public function cetakData()
    {

        $tarikan = 'seluruh';
        $arrData = [
            'data_jalur' => $tarikan,
        ];

        // jika seluruh
        if ($tarikan == 'seluruh') {
            $jenis_tarikan = 'seluruh';

            $porsi_siswa = PorsiSiswa::where('jenis_sekolah_id', auth()->user()->sekolah->jenis_sekolah_id)->first();

            $daya_tampung = DayaTampung::where('sekolah_id', Auth::user()->sekolah_id)
                ->first();
            // dd($daya_tampung);


            $total_diterima_zonasi = null;
            $data_pendaftar_zonasi = LivewirePendaftar::where('sekolah_id', Auth::user()->sekolah_id)
                ->where('jalur', 'zonasi')
                ->where('status', 'diterima')
                ->get();
            // dd($data_pendaftar_zonasi);
            $total_diterima_zonasi = count($data_pendaftar_zonasi);
            $data_diterima_zonasi = ($total_diterima_zonasi == 0) ? 0 : $total_diterima_zonasi;
            $daya_tampung_zonasi = $daya_tampung['daya_tampung'];
            $porsi_zonasi = ($data_diterima_zonasi / $daya_tampung_zonasi) * 100;
            // dd(number_format($porsi_zonasi, 2, ',', '.'));

            $total_diterima_afirmasi = null;
            $data_pendaftar_afirmasi = LivewirePendaftar::where('sekolah_id', Auth::user()->sekolah_id)
                ->where('jalur', 'afirmasi')
                ->where('status', 'diterima')
                ->get();
            // dd($data_pendaftar_afirmasi);

            $total_diterima_afirmasi = count($data_pendaftar_afirmasi);
            $data_diterima_afirmasi = ($total_diterima_afirmasi == 0) ? 0 : $total_diterima_afirmasi;
            $daya_tampung_afirmasi = $daya_tampung['daya_tampung'];
            $porsi_afirmasi = ($data_diterima_afirmasi / $daya_tampung_afirmasi) * 100;
            // dd(number_format($porsi_afirmasi, 2, ',', '.'));

            $total_diterima_mutasi = null;
            $data_pendaftar_mutasi = LivewirePendaftar::where('sekolah_id', Auth::user()->sekolah_id)
                ->where('jalur', 'mutasi')
                ->where('status', 'diterima')
                ->get();
            $total_diterima_mutasi = count($data_pendaftar_mutasi);
            $data_diterima_mutasi = ($total_diterima_mutasi == 0) ? 0 : $total_diterima_mutasi;
            $daya_tampung_mutasi = $daya_tampung['daya_tampung'];
            $porsi_mutasi = ($data_diterima_mutasi / $daya_tampung_mutasi) * 100;
            // dd(number_format($porsi_mutasi, 2, ',', '.'));

            $total_diterima_prestasi = null;
            $data_pendaftar_prestasi = LivewirePendaftar::where('sekolah_id', Auth::user()->sekolah_id)
                ->where('jalur', 'prestasi')
                ->where('status', 'diterima')
                ->get();
            $total_diterima_prestasi = count($data_pendaftar_prestasi);
            $data_diterima_prestasi = ($total_diterima_prestasi == 0) ? 0 : $total_diterima_prestasi;
            $daya_tampung_prestasi = $daya_tampung['daya_tampung'];
            $porsi_prestasi = ($data_diterima_prestasi / $daya_tampung_prestasi) * 100;
            // dd(number_format($porsi_prestasi, 2, ',', '.'));


            $data_daya_tampung = [
                'porsi_afirmasi' => number_format($porsi_afirmasi, 2, ',', '.'),
                'porsi_zonasi' => number_format($porsi_zonasi, 2, ',', '.'),
                'porsi_mutasi' => number_format($porsi_mutasi, 2, ',', '.'),
                'porsi_prestasi' => number_format($porsi_prestasi, 2, ',', '.'),
            ];

            // jika seluruh
            $atribut_jalur = [
                'total_zonasi' => $total_diterima_zonasi,
                'total_afirmasi' => $total_diterima_afirmasi,
                'total_mutasi' => $total_diterima_mutasi,
                'total_prestasi' => $total_diterima_prestasi,
            ];
        }


        // dd($data_pendaftar_zonasi);
        $pdf = DomPDFPDF::loadView(
            'livewire.sekolah.laporan.cetak',
            [
                'jenis_tarikan' => $jenis_tarikan,
                'data_pendaftar_zonasi' => $data_pendaftar_zonasi,
                'data_pendaftar_afirmasi' => $data_pendaftar_afirmasi,
                'data_pendaftar_mutasi' => $data_pendaftar_mutasi,
                'data_pendaftar_prestasi' => $data_pendaftar_prestasi,
                'arrdata' => $arrData,
                'data_daya_tampung' => $data_daya_tampung,
                'atribut_jalur' => $atribut_jalur,
            ]
        )
            ->setPaper('a4', 'landscape')
            ->output();

        return response()->streamDownload(function () use ($pdf) {
            echo $pdf;
        }, 'Laporan data - ' . $this->data_jalur . '.pdf');
    }
}
