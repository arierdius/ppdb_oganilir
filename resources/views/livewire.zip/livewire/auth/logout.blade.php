<div>
    <li class="onhover-dropdown p-0">
        <button wire:click="logout" class="btn btn-primary-light" type="button" ><i data-feather="log-out"></i>Log out</button>
      </li>
</div>
