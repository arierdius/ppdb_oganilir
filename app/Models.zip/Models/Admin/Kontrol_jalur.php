<?php

namespace App\Models\Admin;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Kontrol_jalur extends Model
{
    use HasFactory;

    protected $table = 'kontrol_jalur';
}
