<!DOCTYPE html>
<html>

<head>
    <title>Kartu Pendaftaran</title>
    <style>
        body {
            font-family: Arial, Helvetica, sans-serif;
        }
    </style>
</head>

<body>
    <table border='0' width="100%" style="font-size:25px;">
        <tr>
            <td style="width:10%;">
                <center>
                    <img src="https://ppdb.oganilirkab.go.id/assets_umum/images/logo-oi.png"
                        style="max-width:85px;padding:5px;">
                </center>
            </td>
            <td style="width:70%;vertical-align: text-top;">
                <center><b>KARTU PENDAFTARAN<br> PENERIMAAN PESERTA DIDIK BARU
                        <br> TAHUN 2023</b><br>
                </center>
            </td>

        </tr>
    </table>
    <hr style=" border: 2px solid black;">
    <br>

    <table  width="100%">
        <tr>
            <td rowspan="7" style="width:20%;">
                <center>
                    <img src="https://ppdb.oganilirkab.go.id/storage/foto_siswa/{{ $pendaftaran->detail->foto }}"
                        style="max-width:130px;">
                </center>

            </td>
        <tr>
            <td style="padding:5px;" style="width: 140px;">No Pendaftaran</td>
            <td style="padding:5px;">: {{ $pendaftaran->no_pendaftaran }}</td>
        </tr>
        <tr>
            <td style="padding:5px;" style="width: 140px;">Jalur Pendaftaran</td>
            <td style="padding:5px;">: {{ strtoupper($pendaftaran->jalur) }}</td>
        </tr>

        <tr>
            <td style="padding:5px;" style="width: 140px;">Nama</td>
            <td style="padding:5px;">: {{ strtoupper($pendaftaran->detail->nama_lengkap) }}</td>
        </tr>
        <tr>
            <td style="padding:5px;" style="width: 140px;">NIK</td>
            <td style="padding:5px;">: {{ $pendaftaran->detail->nik }}</td>
        </tr>
        <tr>
            <td style="padding:5px;" style="width: 140px;">Tempat, Tanggal Lahir</td>
            <td style="padding:5px;"> : {{ $pendaftaran->detail->tempat_lahir }},
                {{ date('d-m-Y', strtotime($pendaftaran->detail->tanggal_lahir)) }}</td>
        </tr>
        <tr>
            <td style="padding:5px;"  style="width: 140px;">Jenis Kelamin</td>
            <td style="padding:5px;">: {{ $pendaftaran->detail->jenis_kelamin }}</td>
        </tr>
        <tr>
            <td></td>
            <td style="padding:5px;" style="width: 140px;">Tanggal Daftar</td>
            <td  style="padding:5px;">: {{ date('d-m-Y', strtotime($pendaftaran->tanggal_daftar)) }}</td>
        </tr>
        <tr>
            <td></td>
            <td style="padding:5px;" >Nama Sekolah</td>
            <td  style="padding:5px;">: {{ strtoupper($pendaftaran->sekolah->nama_sekolah) }}</td>
        </tr>
        <tr>
            <td></td>
            <td style="padding:5px;">Alamat Sekolah</td>
            <td  style="padding:5px;">: {{ $pendaftaran->sekolah->alamat }}</td>
        </tr>
    </table>
    <table class="mt-1">
        <tr>
            <td><img src="https://ppdb.oganilirkab.go.id/storage/foto_siswa/qr-code.png" alt=""
                    style="max-width: 80px;float: left;"><br><br><br><br></td>
        </tr>
        <tr>
            <td>
                PERHATIAN : <br>
                - Silahkan print out dan dibawa kesekolah pada saat verifikasi data
            </td>
        </tr>
    </table>


</body>

</html>
