<?php

namespace App\Models\Admin;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Pemberkasan_zonasi extends Model
{
    use HasFactory;
    protected $table = 'pemberkasan_zonasi';
}
