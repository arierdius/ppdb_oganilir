<?php

namespace App\Http\Livewire\Umum\Jadwal;

use Livewire\Component;

class Index extends Component
{
    public function render()
    {
        return view('livewire.umum.jadwal.index')->layout('layouts.umum.app');
    }
}
