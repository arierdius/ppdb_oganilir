<?php

namespace App\Models\Admin;

use App\Models\User;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Factories\HasFactory;

class Zonasi extends Model
{
    use HasFactory;
    public $table = 'zonasi';

}
