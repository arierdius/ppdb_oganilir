<div>


    <div class="medi-services">

        <div class="container">

            <div class="row row-cols-1 row-cols-md-4">

                <!-- <a href="awdawd.html"> -->

                <div class="col">
                    <div class="comon-quick">
                        <div class="text-center">
                            <figure> <img src="{{ asset('assets_umum/images/creative.png') }}" alt="mv" />
                            </figure>
                            <h4>ZONASI</h4>
                        </div>
                    </div>
                </div>
                <!-- </a> -->

                <div class="col">
                    <div class="comon-quick">
                        <div class="text-center">
                            <figure> <img src="{{ asset('assets_umum/images/creative.png') }}" alt="mv" />
                            </figure>
                            <h4>PRESTASI</h4>
                        </div>
                    </div>
                </div>
                <!-- </a> -->

                <div class="col">
                    <div class="comon-quick">
                        <div class="text-center">
                            <figure> <img src="{{ asset('assets_umum/images/creative.png') }}" alt="mv" />
                            </figure>
                            <h4>AFIRMASI</h4>
                        </div>
                    </div>
                </div>
                <!-- </a> -->
                <div class="col">
                    <div class="comon-quick">
                        <div class="text-center">
                            <figure> <img src="{{ asset('assets_umum/images/creative.png') }}" alt="mv" />
                            </figure>
                            <h4>MUTASI</h4>
                        </div>
                    </div>
                </div>



            </div>



        </div>



    </div>


    <div class="new-add-school mt-5">


        <!-- prakata bupati  -->
        <div class="container">

            <div class="row row-cols-1 row-cols-md-2">

                <div class="col">

                    <div class="left-img">

                        <figure>

                            <img src="{{ asset('assets_umum/images/bupatiwakil.png') }}" alt="pc" />

                        </figure>



                    </div>

                </div>

                <div class="col">
                    <h1>
                        <span>
                            <svg xmlns="http://www.w3.org/2000/svg" width="60" height="16" viewBox="0 0 60 16">
                                <path class="shape-color-4" fill="none" stroke="" stroke-width="2"
                                    d="M58.35 6.285c-1.936 1.841-6.788 6.566-6.788 6.566s-.925 1.556-3.394 0c-2.469-1.555-5.939-3.226-5.939-3.226s-1.764-.743-2.546 0c-1.342 1.275-4.242 3.226-4.242 3.226s-.4 1.436-3.394 0c-2.994-1.435-5.94-3.226-5.94-3.226s-1.898-1.423-3.393 0c-1.81 1.721-4.243 3.226-4.243 3.226s-1.228 1.436-3.394 0c-2.166-1.435-5.939-3.226-5.939-3.226s-.588-1.055-1.697 0c-2.499 2.376-4.243 1.501-4.243 1.501L2.35 9.512l8.485-6.453s1.123-.844 2.545 0c1.422.843 6.788 4.033 6.788 4.033s1.098 1.376 2.546 0c1.389-1.321 5.09-4.033 5.09-4.033s1.447-1.204 2.546 0c1.099 1.203 6.788 4.033 6.788 4.033s1.554.942 2.545 0l3.394-3.227s1.644-2.37 3.394-.806c1.751 1.562 6.788 4.033 6.788 4.033s3.285-.702 4.242-1.614">
                                </path>
                            </svg>
                        </span>
                        Prakata Bupati
                        <b>Kabupaten Ogan Ilir</b>
                    </h1>

                    <h5 class="my-3">Assalamu'alaikum Wr. Wb.</h5>

                    <p style="text-align: justify;">Puji syukur kami panjatkan kepada Tuhan Yang Maha Esa karena atas rahmat dan hidayah-Nya,
                        Dinas Pendidikan
                        Kabupaten Ogan Ilir tahun pelajaran 2022/2023 kembali menyelenggarakan agenda Penerimaan
                        Peserta Didik Baru
                        (PPDB), dalam rangka memberikan pelayanan terbaik kepada masyarakat.</p>
                    <a href="#" class="btn book-bn-comon btn btn-info mt-5" title="read more"> Read More <i
                            class="bi bi-caret-right"></i> </a>
                </div>



            </div>

        </div>

        <!-- prakata kepala dinas  -->


        {{-- <div class="kite">

            <div class="tail"></div>

        </div> --}}



    </div>

    <div class="prakata my-150">

        <div class="container">

            <div class="row row-cols-1 row-cols-md-2">

                <div class="col">

                    <h1>
                        <span>
                            <svg xmlns="http://www.w3.org/2000/svg" width="60" height="16" viewBox="0 0 60 16">
                                <path class="shape-color-4" fill="none" stroke="" stroke-width="2"
                                    d="M58.35 6.285c-1.936 1.841-6.788 6.566-6.788 6.566s-.925 1.556-3.394 0c-2.469-1.555-5.939-3.226-5.939-3.226s-1.764-.743-2.546 0c-1.342 1.275-4.242 3.226-4.242 3.226s-.4 1.436-3.394 0c-2.994-1.435-5.94-3.226-5.94-3.226s-1.898-1.423-3.393 0c-1.81 1.721-4.243 3.226-4.243 3.226s-1.228 1.436-3.394 0c-2.166-1.435-5.939-3.226-5.939-3.226s-.588-1.055-1.697 0c-2.499 2.376-4.243 1.501-4.243 1.501L2.35 9.512l8.485-6.453s1.123-.844 2.545 0c1.422.843 6.788 4.033 6.788 4.033s1.098 1.376 2.546 0c1.389-1.321 5.09-4.033 5.09-4.033s1.447-1.204 2.546 0c1.099 1.203 6.788 4.033 6.788 4.033s1.554.942 2.545 0l3.394-3.227s1.644-2.37 3.394-.806c1.751 1.562 6.788 4.033 6.788 4.033s3.285-.702 4.242-1.614">
                                </path>
                            </svg>
                        </span>

                        Prakata Kepala Dinas
                        <b> Pendidikan dan Kebudayaan</b>
                    </h1>

                    <h5 class="my-3">Assalamu'alaikum Wr. Wb.</h5>

                    <p style="text-align: justify;">Puji syukur kami panjatkan kepada Tuhan Yang Maha Esa karena atas rahmat dan hidayah-Nya,
                        Dinas Pendidikan
                        Kabupaten Ogan Ilir tahun pelajaran 2022/2023 kembali menyelenggarakan agenda Penerimaan
                        Peserta Didik Baru
                        (PPDB), dalam rangka memberikan pelayanan terbaik kepada masyarakat.</p>

                    <a href="#" class="btn book-bn-comon btn btn-info mt-5" title="read more"> Read More <i
                            class="bi bi-caret-right"></i> </a>

                </div>

                <div class="col">

                    <div class="left-img">

                        <figure>

                            <img src="{{ asset('assets_umum/images/bupatiwakil.png') }}" alt="pc" />

                        </figure>



                    </div>

                </div>





            </div>

        </div>
    </div>

{{--
    <section class="need-part-sec">

        <div class="container text-center">

            <h1> NEED MORE INFORMATION? </h1>

            <p> Lorem ipsum dolor sit amet consectetur adipisicing elit sed do eiusmod </p>

            <a href="#"> <i class="bi bi-telephone-forward"></i> 1800-229-602 </a>

        </div>

    </section> --}}

</div>
